import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  List<Marker> _marker=[];
  List<Marker> list=const [
    Marker(
        markerId: MarkerId("1"),
      position: LatLng(28.4360704,77.0015232),
      infoWindow: InfoWindow(
        title: 'Your Current Location'
      )
    ),
  ];
  Completer<GoogleMapController> _controller=Completer();
  static final CameraPosition _currentPosition = const CameraPosition(
    target: LatLng(28.4360704,77.0015232),
    zoom: 14.4746,
  );

  @override
  void initState() {
    _marker.addAll(list);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GoogleMap(
        initialCameraPosition: _currentPosition,
        markers: Set<Marker>.of(_marker),
        onMapCreated: (GoogleMapController controller){
          _controller.complete(controller);
        },
      ),
    );
  }
}
